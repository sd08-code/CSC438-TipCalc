Tip Calculator - Custom Tip Amount

A Jetpack Compose app based on the Week 5 class layout.

Custom Tip Amount accepts a fixed money amount and overrides Tip %.
Clear the custom field to return to percentage-based tipping. Zero is valid.
The round-up switch applies to the selected tip. Invalid custom input shows
an error and hides the result. Inputs survive activity recreation.

To run: extract TipCalculator-project.zip and open its TipCalculator folder
in Android Studio. Wait for Gradle sync, choose a device/emulator, and click Run.
Android 7.0 (API 24) or newer is required.

MainActivity.kt: form, hoisted state, reusable text fields, and round-up switch.
TipCalculation.kt: input parsing and tip calculation.
app/src/main/res/values/strings.xml: labels and help text.

Example: Bill 100, Tip % 15, custom empty gives $15.00.
Enter custom 7.50 to get $7.50; turn rounding on to get $8.00.
Clear the custom field to return to $15.00.

The project includes seven JUnit calculation/input tests.
No coursework has been submitted and no GitHub files were changed.
