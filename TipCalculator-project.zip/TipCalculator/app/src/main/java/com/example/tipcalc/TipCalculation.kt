package com.example.tipcalc

import kotlin.math.ceil

// Accept a decimal point or decimal comma; reject negative and non-finite values.
internal fun nonNegativeNumber(input: String): Double? =
    input.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0.0 }

internal fun calculateTip(
    amount: Double,
    tipPercent: Double = 15.0,
    roundUp: Boolean = false,
    customAmount: Double? = null
): Double {
    val tip = customAmount ?: (amount * (tipPercent / 100.0))
    return if (roundUp) ceil(tip) else tip
}

