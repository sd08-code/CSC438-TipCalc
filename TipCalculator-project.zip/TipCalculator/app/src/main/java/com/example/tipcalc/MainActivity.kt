package com.example.tipcalc

import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import java.text.NumberFormat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) { TipCalcLayout() }
            }
        }
    }
}

@Composable
fun TipCalcLayout() {
    var amountInput by rememberSaveable { mutableStateOf("") }
    var tipInput by rememberSaveable { mutableStateOf("15") }
    var customAmountInput by rememberSaveable { mutableStateOf("") }
    var roundUp by rememberSaveable { mutableStateOf(false) }
    val amount = nonNegativeNumber(amountInput) ?: 0.0
    val tipPercent = nonNegativeNumber(tipInput) ?: 0.0
    val customAmount = nonNegativeNumber(customAmountInput)
    val customAmountInvalid = customAmountInput.isNotBlank() && customAmount == null
    val tip = calculateTip(amount, tipPercent, roundUp, customAmount)
    val focusManager = LocalFocusManager.current
    val next = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })
    val fieldModifier = Modifier.padding(bottom = 24.dp).fillMaxWidth()

    Column(
        modifier = Modifier.fillMaxSize()
            .padding(horizontal = 40.dp).verticalScroll(rememberScrollState())
            .safeDrawingPadding().imePadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(R.string.calculate_tip),
            modifier = Modifier.padding(bottom = 16.dp, top = 40.dp).align(Alignment.Start)
        )
        EditNumberField(
            value = amountInput,
            onValueChange = { amountInput = it },
            label = stringResource(R.string.bill_amount),
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
            keyboardActions = next,
            modifier = fieldModifier,
            isError = amountInput.isNotBlank() && nonNegativeNumber(amountInput) == null
        )
        EditNumberField(
            value = tipInput,
            onValueChange = { tipInput = it },
            label = stringResource(R.string.tip_percentage),
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
            keyboardActions = next,
            modifier = fieldModifier,
            isError = tipInput.isNotBlank() && nonNegativeNumber(tipInput) == null
        )
        EditNumberField(
            value = customAmountInput,
            onValueChange = { customAmountInput = it },
            label = stringResource(R.string.custom_tip_amount),
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
            modifier = fieldModifier,
            isError = customAmountInvalid,
            supportingText = if (customAmountInvalid) stringResource(R.string.invalid_amount)
                else stringResource(R.string.custom_tip_help)
        )
        RoundTipRow(roundUp = roundUp, onRoundUpChanged = { roundUp = it })
        if (!customAmountInvalid) {
            Text(
                text = stringResource(R.string.tip_amount, NumberFormat.getCurrencyInstance().format(tip)),
                style = MaterialTheme.typography.displaySmall,
                modifier = Modifier.padding(top = 24.dp)
            )
        }
        Spacer(modifier = Modifier.height(150.dp))
    }
}

@Composable
fun EditNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    keyboardOptions: KeyboardOptions,
    keyboardActions: KeyboardActions,
    modifier: Modifier = Modifier,
    isError: Boolean = false,
    supportingText: String? = null
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        modifier = modifier,
        isError = isError,
        supportingText = { if (supportingText != null) Text(supportingText) }
    )
}

@Composable
fun RoundTipRow(roundUp: Boolean, onRoundUpChanged: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(R.string.round_up_tip), modifier = Modifier.weight(1f))
        Switch(checked = roundUp, onCheckedChange = onRoundUpChanged)
    }
}

@Preview(showBackground = true)
@Composable
fun TipCalcPreview() {
    MaterialTheme { TipCalcLayout() }
}
