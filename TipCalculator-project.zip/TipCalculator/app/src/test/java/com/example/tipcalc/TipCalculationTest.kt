package com.example.tipcalc

import org.junit.Assert.*
import org.junit.Test

class TipCalculationTest {
    @Test fun percentageIsUsedWhenCustomAmountIsEmpty() {
        assertEquals(15.0, calculateTip(100.0, 15.0), 0.0001)
        assertEquals(20.0, calculateTip(100.0, 20.0, customAmount = nonNegativeNumber("")), 0.0001)
    }
    @Test fun customMoneyAmountOverridesPercentage() {
        assertEquals(7.50, calculateTip(100.0, 20.0, customAmount = 7.50), 0.0001)
    }
    @Test fun zeroIsAValidCustomAmount() {
        assertEquals(0.0, calculateTip(100.0, 20.0, customAmount = 0.0), 0.0001)
    }
    @Test fun clearingCustomAmountRestoresPercentage() {
        val clearedAmount = nonNegativeNumber("")
        assertNull(clearedAmount)
        assertEquals(20.0, calculateTip(100.0, 20.0, customAmount = clearedAmount), 0.0001)
    }
    @Test fun roundUpAppliesToCustomAndPercentageTips() {
        assertEquals(8.0, calculateTip(100.0, 20.0, true, 7.50), 0.0001)
        assertEquals(3.0, calculateTip(19.99, 15.0, true), 0.0001)
        assertEquals(7.0, calculateTip(100.0, 20.0, true, 7.0), 0.0001)
    }
    @Test fun decimalInputIsSupported() {
        assertEquals(7.5, nonNegativeNumber(" 7.50 ")!!, 0.0001)
        assertEquals(7.5, nonNegativeNumber("7,50")!!, 0.0001)
    }
    @Test fun invalidAmountsAreRejected() {
        listOf("-1", "abc", "NaN", "Infinity", "1..2").forEach {
            assertNull("Expected invalid input: $it", nonNegativeNumber(it))
        }
    }
}
